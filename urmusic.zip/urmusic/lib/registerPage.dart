import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:urmusic/Color.dart';
import 'package:urmusic/loginPage.dart';
import 'package:urmusic/navigation.dart';
class registerPage extends StatefulWidget {
  const registerPage({super.key});

  @override
  State<registerPage> createState() => _registerPageState();
}

class _registerPageState extends State<registerPage> {
  GlobalKey<FormState> formkey=GlobalKey<FormState>();

  String selectedGender = 'male';


  //Image pick
  File? imageFile;

  Future<void> _pickImage(ImageSource source) async {
    final picker = ImagePicker();
    final pickedImage = await picker.pickImage(source: source);

    setState(() {
      if (pickedImage != null) {
        imageFile = File(pickedImage.path);
      } else {
        print('No image selected.');
      }
    });
  }
  //show bottom sheet camera and gallery
  void showImagePicker(BuildContext context) {
    showModalBottomSheet(
      context: context,
      builder: (BuildContext context) {
        return SafeArea(
          child: Wrap(
            children: <Widget>[
              ListTile(
                leading: const Icon(Icons.photo_library),
                title: const Text('Gallery'),
                onTap: () {
                  _pickImage(ImageSource.gallery);
                  Navigator.of(context).pop();
                },
              ),
              ListTile(
                leading: const Icon(Icons.photo_camera),
                title: const Text('Camera'),
                onTap: () {
                  _pickImage(ImageSource.camera);
                  Navigator.of(context).pop();
                },
              ),
            ],
          ),
        );
      },
    );
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(


      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Form(
            key: formkey,
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Sign up',style: TextStyle(fontSize: 22,fontWeight: FontWeight.bold),),
              
                  //image
                  Center(
                    child: Stack(
                      children: [
                        Container( height: 100,width: 100,
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(80),
                            child: imageFile != null
                                ? Image.file(
                              imageFile!.absolute,
                              fit: BoxFit.cover,
                            )
                                : Image.asset(
                              'assets/user.png',
                              scale: 5,
                            ),
                            // Image.network('https://img.freepik.com/premium-vector/man-avatar-profile-picture-vector-illustration_268834-538.jpg'),
                          ),
                        ),
                        Positioned(
                          bottom: 15,
                          right: 10,
                          child: InkWell(
                            borderRadius: BorderRadius.circular(60),
                            onTap: () {
                              showImagePicker(context);
                            },
                            child: Icon(Icons.add_a_photo,size: 80,color: Colors.transparent,),
                          ),
                        ),
                      ],
                    ),
                  ),
              
                  TextFormField(
                    decoration: InputDecoration(
                      hintText: 'Email ID',
                      labelText: 'Enter Email',
                      prefixIcon: Icon(Icons.alternate_email),
                    ),
                    validator: (val){
                      if(val!.isEmpty)
                      {
                        return 'Please a Enter';
                      }
                      if(!RegExp("^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+.[a-z]").hasMatch(val)){
                        return 'Please a valid Email';
                      }
                      return null;
                    },
                  ),
              
                  TextFormField(
                    decoration: InputDecoration(
                      hintText: 'Enter name',
                      labelText: 'Full name',
                      prefixIcon: Icon(Icons.person_2_outlined),
                    ),
                    validator: (val){
                      if(val!.isEmpty)
                      {
                        return 'Required';
                      }
                      return null;
                    },
                  ),
              
                  TextFormField(
                    keyboardType: TextInputType.phone,
                    decoration: InputDecoration(
                      hintText: 'Mobile',
                      labelText: 'Mobile',
                      prefixIcon: Icon(Icons.local_phone_outlined),
                    ),
                    validator: (val){
                      if(val!.isEmpty)
                      {
                        return 'Required';
                      }
                      return null;
                    },
                  ),
              
                  TextFormField(
                    obscureText: true,
                    decoration: InputDecoration(
                      hintText: 'Password',
                      labelText: 'Password',
                      prefixIcon: Icon(Icons.lock_outline),
                    ),
                    validator: (val){
                      if(val!.isEmpty)
                      {
                        return 'Required';
                      }
                      return null;
                    },
                  ),
                  
                  TextFormField(
                    obscureText: true,
                    decoration: InputDecoration(
                      hintText: 'Confirm Password',
                      labelText: 'Confirm Password',
                      prefixIcon: Icon(Icons.lock_outline),
                    ),
                    validator: (val){
                      if(val!.isEmpty)
                      {
                        return 'Required';
                      }
                      return null;
                    },
                  ),

                  SizedBox(height: 5,),
                  Row(
                    children: [
                      Radio(
                        activeColor: primaryColor,
                        value: 'male',
                        groupValue: selectedGender,
                        onChanged: (value) {
                          setState(() {
                            selectedGender = value as String;
                          });
                        },
                      ),
                      Text('Male'),
                      SizedBox(width: 16), // Adjust spacing as needed
                      Radio(
                        activeColor: primaryColor,
                        value: 'female',
                        groupValue: selectedGender,
                        onChanged: (value) {
                          setState(() {
                            selectedGender = value as String;
                          });
                        },
                      ),
                      Text('Female'),
                    ],
                  ),

                  SizedBox(height: 5,),
                  Padding(
                    padding: const EdgeInsets.only(left: 8,right: 8),
                    child: Column(
                      children: [
                        Row(
                          children: [
                            Text('By signing up re agree to our '),
                            InkWell(
                              onTap: (){},
                              child: Text('Term and Condition',style: TextStyle(fontWeight: FontWeight.w500,color: primaryColor),),
                            ),
                          ],
                        ),
                        Row(
                          children: [
                            Text('and '),
                            InkWell(
                                onTap: (){},
                                child: Text('Privacy Policy',style: TextStyle(fontWeight: FontWeight.w500,color: primaryColor),)
                            ),
                          ],
                        ),
                      ],


                    ),
                  ),


                  SizedBox(height: 5,),
                  OutlinedButton(
                      style: OutlinedButton.styleFrom(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10.0), // Set border radius here
                        ),
                      ),
                      onPressed: (){
                        if(formkey.currentState!.validate()){
                          Navigator.push(context, MaterialPageRoute(builder: (context)=>navigation()));
                          print("ok");
                        }else{
                          print("Error");
                        }
                      },
                      child: Center(child: Text('Register',style: TextStyle(fontWeight: FontWeight.w500,color: primaryColor),))
                  ),

                  SizedBox(height: 4,),

                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text('Already have an account?'),
                      InkWell(
                          onTap: (){
                            Navigator.push(context, MaterialPageRoute(builder: (context)=>loginPage()));
                          },
                          child: Text('Login',style: TextStyle(color: primaryColor,fontWeight: FontWeight.w500,fontSize: 17),)
                      )
                    ],
                  ),
              
              
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
