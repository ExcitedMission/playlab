import 'package:easy_search_bar/easy_search_bar.dart';
import 'package:flutter/material.dart';
import 'package:google_nav_bar/google_nav_bar.dart';
import 'package:provider/provider.dart';
import 'package:urmusic/Color.dart';
import 'package:urmusic/DrawerPage/downloads.dart';
import 'package:urmusic/DrawerPage/entertainment.dart';
import 'package:urmusic/DrawerPage/favourite.dart';
import 'package:urmusic/DrawerPage/playList.dart';
import 'package:urmusic/DrawerPage/profile.dart';
import 'package:urmusic/DrawerPage/settings.dart';
import 'package:urmusic/DrawerPage/suggestion.dart';
import 'package:urmusic/NavigatorPage/albums.dart';
import 'package:urmusic/DrawerPage/allSongs.dart';
import 'package:urmusic/NavigatorPage/artist.dart';
import 'package:urmusic/NavigatorPage/catagories.dart';
import 'package:urmusic/DrawerPage/myPlaylist.dart';
import 'package:urmusic/DrawerPage/musicLibrary.dart';
import 'package:urmusic/NavigatorPage/recently.dart';
import 'package:urmusic/NavigatorPage/homePage.dart';
import 'package:urmusic/model_theme.dart';
class navigation extends StatefulWidget {
  const navigation({super.key});

  @override
  State<navigation> createState() => _navigationState();
}

class _navigationState extends State<navigation> {
  int currentindex = 0;

  double _value =50;
  double value1 =70;

  final screens=[const homePage(),const catagories(),const artist(),const albums(),const recently()];
  List<String> screentitle=['Home','Categories','Artist','Albums','Recently'];

  String searchValue = '';


  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: EasySearchBar(
        elevation: 0,
        backgroundColor: context.watch<ModelTheme>().isDark ? Colors.black54 :accentColor,
        title: Center(
          child: Text(screentitle[currentindex],
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              )),
        ),
        //centerTitle: true,
          onSearch: (value) => setState(() => searchValue = value),

      ),

        drawer: Drawer(

          child: SafeArea(
            child: Padding(
              padding: const EdgeInsets.only(left: 20,top: 10),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [

                        Image.asset('assets/musiclogo.png',scale: 10,),
                        SizedBox(width: 20,),

                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('URMUSIC',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 18),),
                            Text('Made With in USA',style: TextStyle(color: Colors.grey),),
                          ],
                        )
                      ],
                    ),
                    SizedBox(height: 20,),
                    Divider(),

                    ListTile(
                      onTap: () {
                        setState(() {
                          currentindex = 0; // Change to the index of "Categories" tab
                        });
                        Navigator.pop(context);                      },
                      contentPadding: EdgeInsets.all(-10),
                      title: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Icon(Icons.home_outlined,size: 22,),
                          SizedBox(width: 30,),
                          Text('Home', style: TextStyle(fontWeight: FontWeight.w500),
                          ),
                        ],
                      ),
                    ),

                    ListTile(
                      onTap: () {
                        setState(() {
                          currentindex = 1; // Change to the index of "Categories" tab
                        });
                        Navigator.pop(context);
                      },
                      contentPadding: EdgeInsets.all(-10),
                      title: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Icon(Icons.drive_file_move_outline,size: 22,),
                          SizedBox(width: 30,),
                          Text('Catagories', style: TextStyle(fontWeight: FontWeight.w500),
                          ),
                        ],
                      ),
                    ),

                    ListTile(
                      onTap: () {
                        setState(() {
                          currentindex = 2; // Change to the index of "Categories" tab
                        });
                        Navigator.pop(context);
                      },
                      contentPadding: EdgeInsets.all(-10),
                      title: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Icon(Icons.person_search_outlined,size: 22,),
                          SizedBox(width: 30,),
                          Text('Artist', style: TextStyle(fontWeight: FontWeight.w500),
                          ),
                        ],
                      ),
                    ),

                    ListTile(
                      onTap: () {
                        setState(() {
                          currentindex = 3; // Change to the index of "Categories" tab
                        });
                        Navigator.pop(context);
                      },
                      contentPadding: EdgeInsets.all(-10),
                      title: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Icon(Icons.album_outlined,size: 22,),
                          SizedBox(width: 30,),
                          Text('Albums', style: TextStyle(fontWeight: FontWeight.w500),
                          ),
                        ],
                      ),
                    ),
                    ListTile(
                      onTap: () {
                        setState(() {
                          currentindex = 4; // Change to the index of "Categories" tab
                        });
                        Navigator.pop(context);
                      },
                      contentPadding: EdgeInsets.all(-10),
                      title: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Icon(Icons.watch_later_outlined,size: 22,),
                          SizedBox(width: 30,),
                          Text('Recently', style: TextStyle(fontWeight: FontWeight.w500),
                          ),
                        ],
                      ),
                    ),
                    ListTile(
                      onTap: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>allSongs()));
                      },
                      contentPadding: EdgeInsets.all(-10),
                      title: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Icon(Icons.music_note_outlined,size: 22,),
                          SizedBox(width: 30,),
                          Text('All Songs', style: TextStyle(fontWeight: FontWeight.w500),
                          ),
                        ],
                      ),
                    ),

                    ListTile(
                      onTap: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>Playlist()));
                      },
                      contentPadding: EdgeInsets.all(-10),
                      title: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Icon(Icons.playlist_play,size: 22,),
                          SizedBox(width: 30,),
                          Text('Playlist', style: TextStyle(fontWeight: FontWeight.w500),
                          ),
                        ],
                      ),
                    ),

                    ListTile(
                      onTap: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>myPlaylist()));
                      },
                      contentPadding: EdgeInsets.all(-10),
                      title: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Icon(Icons.playlist_play,size: 22,),
                          SizedBox(width: 30,),
                          Text('My Playlist', style: TextStyle(fontWeight: FontWeight.w500),
                          ),
                        ],
                      ),
                    ),

                    ListTile(
                      onTap: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>musicLibrary()));
                      },
                      contentPadding: EdgeInsets.all(-10),
                      title: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Icon(Icons.library_music_outlined,size: 22,),
                          SizedBox(width: 30,),
                          Text('Music Library', style: TextStyle(fontWeight: FontWeight.w500),
                          ),
                        ],
                      ),
                    ),

                    ListTile(
                      onTap: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>favourite()));
                      },
                      contentPadding: EdgeInsets.all(-10),
                      title: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Icon(Icons.favorite_border,size: 22,),
                          SizedBox(width: 30,),
                          Text('Favourite', style: TextStyle(fontWeight: FontWeight.w500),
                          ),
                        ],
                      ),
                    ),

                    ListTile(
                      onTap: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>downloads()));
                      },
                      contentPadding: EdgeInsets.all(-10),
                      title: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Icon(Icons.download_outlined,size: 22,),
                          SizedBox(width: 30,),
                          Text('Downloads', style: TextStyle(fontWeight: FontWeight.w500),
                          ),
                        ],
                      ),
                    ),

                    ListTile(
                      onTap: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>entertainment()));
                      },
                      contentPadding: EdgeInsets.all(-10),
                      title: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Icon(Icons.assignment_outlined,size: 22,),
                          SizedBox(width: 30,),
                          Text('Entertainment', style: TextStyle(fontWeight: FontWeight.w500),
                          ),
                        ],
                      ),
                    ),

                    ListTile(
                      onTap: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>suggestion()));
                      },
                      contentPadding: EdgeInsets.all(-10),
                      title: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Icon(Icons.manage_search,size: 22,),
                          SizedBox(width: 30,),
                          Text('Suggestion', style: TextStyle(fontWeight: FontWeight.w500),
                          ),
                        ],
                      ),
                    ),

                    ListTile(
                      onTap: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>profilePage()));
                      },
                      contentPadding: EdgeInsets.all(-10),
                      title: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Icon(Icons.account_circle_outlined,size: 22,),
                          SizedBox(width: 30,),
                          Text('Profile', style: TextStyle(fontWeight: FontWeight.w500),
                          ),
                        ],
                      ),
                    ),

                    ListTile(
                      onTap: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>settings()));
                      },
                      contentPadding: EdgeInsets.all(-10),
                      title: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Icon(Icons.settings,size: 22,),
                          SizedBox(width: 30,),
                          Text('Settings', style: TextStyle(fontWeight: FontWeight.w500),
                          ),
                        ],
                      ),
                    ),
                    ListTile(
                      onTap: () {},
                      contentPadding: EdgeInsets.all(-10),
                      title: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Icon(Icons.login_rounded,size: 22,),
                          SizedBox(width: 30,),
                          Text('Log out', style: TextStyle(fontWeight: FontWeight.w500),
                          ),
                        ],
                      ),
                    ),


                  ],

                ),
              ),
            ),
          ),

        ),

        // navigator
        bottomNavigationBar:
        Container(
          decoration: BoxDecoration(
            boxShadow: [
              BoxShadow(
                blurRadius: 20,
                color: Colors.black.withOpacity(.1),
              )
            ],
            color: context.watch<ModelTheme>().isDark ? Colors.black54 :accentColor,
          ),
          child: SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 8),
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: GNav(
                  // rippleColor: Colors.grey[300]!,
                  // hoverColor: Colors.grey[100]!,
                  gap: 1,
                  activeColor: primaryColor,
                  iconSize: 24,
                  padding: EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                  duration: Duration(milliseconds: 400),
                  tabBackgroundColor: context.watch<ModelTheme>().isDark ? Colors.grey[700]! : Colors.grey[100]!,
                  tabs: [
                    GButton(
                      icon: Icons.home_outlined,
                      text: 'Home',
                    ),
                    GButton(
                      icon: Icons.radio_outlined,
                      text: 'Categories',
                    ),
                    GButton(
                      icon: Icons.music_video_sharp,
                      text: 'Artist',
                    ),
                    GButton(
                      icon: Icons.album_outlined,
                      text: 'Albums',
                    ),
                    GButton(
                      icon: Icons.more_time_outlined,
                      text: 'Recently',
                    ),
                  ],
                  selectedIndex: currentindex,
                  //currentIndex: currentindex,
                  onTabChange: (value) {

                        setState(() {
                          currentindex = value;
                        });
                      },
                ),
              ),
            ),
          ),
        ),
        // BottomNavigationBar(
        //
        //     type: BottomNavigationBarType.shifting,
        //     fixedColor: primaryColor,   //if it is shifting
        //     iconSize: 25,
        //     unselectedItemColor: context.watch<ModelTheme>().isDark ? Colors.white : Colors.black, // selectedIconTheme: const IconThemeData(color: Colors.blueGrey),// unselectedIconTheme: const IconThemeData(color: Colors.amber),// selectedFontSize: 20,// unselectedFontSize: 13,
        //
        //     landscapeLayout: BottomNavigationBarLandscapeLayout.spread,
        //
        //
        //     onTap: (value) {
        //       currentindex = value;
        //       setState(() {
        //       });
        //     },
        //     items: const [
        //       BottomNavigationBarItem(
        //           icon: Icon(Icons.home),
        //           label: 'Home'),
        //       BottomNavigationBarItem(
        //           icon: Icon(Icons.radio_outlined),
        //           label: 'Categories'),
        //       BottomNavigationBarItem(
        //           icon: Icon(Icons.music_video_sharp),
        //           label: 'Artist'),
        //       BottomNavigationBarItem(
        //           icon: Icon(Icons.album_outlined),
        //           label: 'Albums'),
        //       BottomNavigationBarItem(
        //           icon: Icon(Icons.more_time_outlined),
        //           label: 'Recently'),
        //     ]
        // ),


        floatingActionButton: Container(
          decoration: BoxDecoration(
            //color: context.watch<ModelTheme>().isDark ? Colors.black : Colors.white,
          ),
          height: 40,
          width: double.maxFinite,
          child: Padding(
            padding: const EdgeInsets.only(left: 30,),
            child: FloatingActionButton(
              backgroundColor: context.watch<ModelTheme>().isDark ? Colors.black : Colors.white,
              disabledElevation: 0,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Icon(Icons.keyboard_arrow_up_rounded),
                  Row(
                    children: [
                      IconButton(
                        onPressed: (){},
                          icon: Icon(Icons.skip_previous)
                      ),
                      IconButton(
                        onPressed: (){},
                          icon: Icon(Icons.play_arrow_rounded)
                      ),
                      IconButton(
                        onPressed: (){},
                          icon: Icon(Icons.skip_next)
                      ),
                    ],
                  ),
                ],
              ),
              elevation: 0,
                onPressed: (){
                   showBottomSheet();
                }
            ),
          ),
        ),

        body: IndexedStack(index: currentindex,children: screens,),

    );
  }

  void showBottomSheet() {
    showModalBottomSheet(
      context: context,
      builder: (BuildContext context) {
        return StatefulBuilder(
          builder: (BuildContext context, StateSetter setState) {
            return Container(
              // Your bottom sheet content
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [

                      Text('0:00'),
                      SliderTheme(
                        data: SliderTheme.of(context).copyWith(
                          activeTrackColor: primaryColor,
                          trackHeight: 1,
                          thumbShape: RoundSliderThumbShape(
                            enabledThumbRadius: 5.0,
                          ),
                          thumbColor: primaryColor,
                        ),
                        child: Slider(
                          value: _value, // Use the state variable here
                          min: 0,
                          max: 100,
                          onChanged: (value) {
                            setState(() {
                              _value = value; // Update the state variable
                            });
                          },
                        ),
                      ),
                      Text('0:00'),
                      //SizedBox(height: 0,)
                    ],
                  ),
                  // Other widgets in your bottom sheet
                  SizedBox(height: 10),
                  Text('Morning Songs', style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
                  SizedBox(height: 10),
                  Text('Tamrat Desta', style: TextStyle(fontSize: 17)),

                  Row(mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.star,size: 17,),
                      Icon(Icons.star,size: 17,),
                      Icon(Icons.star,size: 17,),
                      Icon(Icons.star,size: 17,),
                      Icon(Icons.star,size: 17,),
                    ],
                  ),
                  Text('1/2'),
                  SizedBox(height: 15,),

                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [

                      IconButton(
                        onPressed: (){},
                        icon: Icon(Icons.alt_route_outlined,size: 26,),
                      ),
                      IconButton(
                        onPressed: (){},
                        icon: Icon(Icons.skip_previous,size: 26,),
                      ),

                      Container(
                          decoration: BoxDecoration(
                              color: primaryColor,
                              borderRadius: BorderRadiusDirectional.circular(60)
                          ),
                          child: IconButton(
                              onPressed: (){},
                              icon: Icon(Icons.play_arrow_rounded,size: 45,)
                          )
                      ),
                      IconButton(
                        onPressed: (){},
                        icon: Icon(Icons.skip_next,size: 26,),
                      ),
                      IconButton(
                        onPressed: (){},
                        icon: Icon(Icons.repeat,size: 26,),
                      ),


                    ],
                  ),
                  // Rest of your widgets...

                  SizedBox(height: 10,),
                  Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [

                      IconButton(onPressed: (){}, icon: Icon(Icons.volume_down)),
                      SliderTheme(
                        data: SliderTheme.of(context).copyWith(
                          activeTrackColor: primaryColor,
                          trackHeight: 1,
                          thumbShape: RoundSliderThumbShape(
                            enabledThumbRadius: 5.0,
                          ),
                          thumbColor: primaryColor,
                        ),
                        child: Slider(
                          value: value1, // Use the state variable here
                          min: 0,
                          max: 100,
                          onChanged: (value) {
                            setState(() {
                              value1 = value; // Update the state variable
                            });
                          },
                        ),
                      ),
                      IconButton(onPressed: (){}, icon: Icon(Icons.volume_up))
                      //SizedBox(height: 0,)
                    ],
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

}
