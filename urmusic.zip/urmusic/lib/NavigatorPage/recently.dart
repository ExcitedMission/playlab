import 'package:flutter/material.dart';
import 'package:urmusic/Color.dart';
class recently extends StatefulWidget {
  const recently({super.key});

  @override
  State<recently> createState() => _recentlyState();
}

class _recentlyState extends State<recently> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('No Songs Found',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 18),),
            SizedBox(height: 10,),

            Center(
              child: Container(
                width: 127, // Set the width as needed
                height: 35, // Set the height as needed

                child: OutlinedButton(
                  onPressed: () {
                    // Handle button press
                  },
                  child:  Row(mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.refresh,color: primaryColor,),
                      SizedBox(width: 5,),
                      Text('Refresh',style: TextStyle(fontWeight: FontWeight.bold,color: primaryColor),)
                    ],
                  ),
                  style: OutlinedButton.styleFrom(
                    side: BorderSide(
                      color: grayColor,
                      //width: 2.0,          // Set the border width
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8.0), // Set the border radius
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      )
    );
  }
}
