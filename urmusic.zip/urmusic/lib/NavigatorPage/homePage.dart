import 'package:flutter/material.dart';
import 'package:urmusic/Color.dart';
class homePage extends StatefulWidget {
  const homePage({super.key});

  @override
  State<homePage> createState() => _homePageState();
}

class _homePageState extends State<homePage> {

  final List<String> imagePaths = ['assets/arijitsing.jpg', 'assets/arijitsing.jpg'];
  final List<String> itemNames = ['Arijit Sing', 'Name 2'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.all(8.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [

                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: [
                      Container(color: Colors.grey,
                        height: 200,width: 350,
                        child: Image.asset('assets/musiclogo.png'),
                      ),
                      Container(color: Colors.grey,
                        height: 200,width: 350,
                        child: Image.asset('assets/musiclogo.png'),
                      ),
                    ],
                  ),
                ),

                SizedBox(height: 10,),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('Artist',style: TextStyle(fontSize: 20),),

                    InkWell(
                      onTap: (){},
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Text('See All ',style: TextStyle(fontSize: 17,color: grayColor)),
                          Container(color: primaryColor,
                              child: Icon(Icons.arrow_forward_ios,size: 22,color: accentColor,)
                          )
                        ],
                      ),
                    )

                  ],
                ),

                SizedBox(height: 10,),

                Container(
                  height: 160, // Adjust the height as needed
                  child: ListView.builder(
                    scrollDirection: Axis.horizontal,
                    itemCount: 6,
                    itemBuilder: (context, index) {
                      return Container(
                        width: 110, // Adjust the width as needed
                        margin: EdgeInsets.all(8),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              height: 110,
                              width: MediaQuery.of(context).size.width,
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(80),
                                child: Image.asset(
                                  'assets/arijitsing.jpg',
                                  scale: 5,
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                            SizedBox(height: 8),
                            Text(
                              "arijit", // Use the name for the current index
                              textAlign: TextAlign.center,
                              style: TextStyle(fontSize: 14),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),




                //album
                SizedBox(height: 1,),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('Album',style: TextStyle(fontSize: 20),),

                    InkWell(
                      onTap: (){},
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Text('See All ',style: TextStyle(fontSize: 17,color: grayColor)),
                          Container(color: primaryColor,
                              child: Icon(Icons.arrow_forward_ios,size: 22,color: accentColor,)
                          )
                        ],
                      ),
                    )

                  ],
                ),
                SizedBox(height: 5,),
                Row(
                  children: [
                    Container( height: 130,width: 130,
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(20),
                        child: Image.asset('assets/arijitsing.jpg',),
                      ),
                    ),
                  ],
                ),

                //category
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('Category',style: TextStyle(fontSize: 20),),

                    InkWell(
                      onTap: (){},
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Text('See All ',style: TextStyle(fontSize: 17,color: grayColor)),
                          Container(color: primaryColor,
                              child: Icon(Icons.arrow_forward_ios,size: 22,color: accentColor,)
                          )
                        ],
                      ),
                    )

                  ],
                ),
                SizedBox(height: 5,),


                Row(
                  children: [
                    Container( height: 130,width: 130,
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: Image.asset('assets/img.png', scale: 5,),
                      ),
                    ),
                  ],
                ),


              ],
            ),
          ),
        ),
      ),

      //bottomNavigationBar:BottomNavigationBar(),
    );
  }
}
