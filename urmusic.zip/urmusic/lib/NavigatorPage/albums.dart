import 'package:flutter/material.dart';
import 'package:urmusic/Color.dart';
class albums extends StatefulWidget {
  const albums({super.key});

  @override
  State<albums> createState() => _albumsState();
}

class _albumsState extends State<albums> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [



              Container(
                width: 160, // Adjust the width as needed
                margin: EdgeInsets.all(8),
                child: Stack(
                //crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    height: 160,
                    width: MediaQuery.of(context).size.width,
                    child: Image.asset(
                      'assets/electric.png',
                      scale: 5,
                      fit: BoxFit.cover,
                    ),
                  ),

                  Padding(
                    padding: const EdgeInsets.only(top: 110,left: 20),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Electric Mob", // Use the name for the current index
                          textAlign: TextAlign.center,
                          style: TextStyle(color: accentColor,fontWeight: FontWeight.bold),
                        ),
                        Text('Songs',style: TextStyle(color: accentColor,),)
                      ],
                    ),
                  ),
                ],
                                   ),
              )
            ],
          ),
        ),
      )
    );
  }
}
