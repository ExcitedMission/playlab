import 'package:easy_search_bar/easy_search_bar.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:urmusic/Color.dart';
import 'package:urmusic/model_theme.dart';
class allSongs extends StatefulWidget {
  const allSongs({super.key});

  @override
  State<allSongs> createState() => _allSongsState();
}

class _allSongsState extends State<allSongs> {
  String searchValue = '';
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: EasySearchBar(
        elevation: 0,
        backgroundColor: context.watch<ModelTheme>().isDark ? Colors.black54 :accentColor,
        title: Text('All Songs',
            style: const TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            )),
        //centerTitle: true,
        onSearch: (value) => setState(() => searchValue = value),

      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                //color: Colors.green,
                height: 700, // Adjust the height as needed
                width: double.infinity,
                child: ListView.builder(
                  scrollDirection: Axis.vertical,

                  itemCount: 5,
                  itemBuilder: (context, index) {
                    return Column(
                      children: [
                        Container(
                          margin: EdgeInsets.all(8),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                child: Image.asset(
                                  'assets/arijitsing.jpg',
                                  scale: 12,
                                  fit: BoxFit.cover,
                                ),
                              ),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text("Morning Songs", style: TextStyle(fontSize: 14),),
                                  Text("Tamrat Desta", style: TextStyle(fontSize: 12),),
                                  Row(
                                    children: [
                                      Icon(Icons.star,size: 17,),
                                      Icon(Icons.star,size: 17,),
                                      Icon(Icons.star,size: 17,),
                                      Icon(Icons.star,size: 17,),
                                      Icon(Icons.star,size: 17,),
                                      SizedBox(width: 5,),
                                      Icon(Icons.remove_red_eye_outlined,size: 17,),
                                      Text('0'),
                                      SizedBox(width: 5,),
                                      Icon(Icons.file_download_outlined,size: 17,),
                                      Text('0')
                                    ],
                                  )
                                ],
                              ),
                              SizedBox(width: 15),

                              IconButton(
                                onPressed:(){},
                                  icon: Icon(Icons.cloud_download_outlined,size: 35,)
                              ),
                              IconButton(
                                onPressed:(){},
                                  icon: Icon(Icons.more_vert_outlined,size: 30,),
                              ),

                            ],
                          ),
                        ),
                        Divider(height: 0,),
                      ],
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
