import 'package:flutter/material.dart';
import 'package:urmusic/Color.dart';
class entertainment extends StatefulWidget {
  const entertainment({super.key});

  @override
  State<entertainment> createState() => _entertainmentState();
}

class _entertainmentState extends State<entertainment> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Entertainment',
            style: const TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            )),
        centerTitle: true,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ListTile(
                onTap: (){},
                title: Text('Boom Play'),
                trailing: IconButton(
                  onPressed: (){},
                  icon: Icon(Icons.arrow_forward),
                ),
                leading: Container(
                  width: 50,height: 50,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(50),
                    color: primaryColor,
                  ),

                  child: Text('B',textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 30,fontWeight: FontWeight.bold),),
                ),
              ),
              Divider(height: 4,),
              ListTile(
                onTap: (){},
                title: Text('World Radio Station'),
                trailing: IconButton(
                  onPressed: (){},
                  icon: Icon(Icons.arrow_forward),
                ),
                leading: Container(
                  width: 50,height: 50,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(50),
                    color: purpleColor,
                  ),

                  child: Text('W',textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 30,fontWeight: FontWeight.bold),),
                ),
              ),
              Divider(height: 5,),
            ],
          ),
        ),
      ),
    );
  }
}
