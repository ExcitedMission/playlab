import 'package:flutter/material.dart';
import 'package:urmusic/Color.dart';
class profilePage extends StatefulWidget {
  const profilePage({super.key});

  @override
  State<profilePage> createState() => _profilePageState();
}

class _profilePageState extends State<profilePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Profile ',style: TextStyle(fontWeight: FontWeight.w600),),
        centerTitle: true,
        actions: [
          IconButton(
              onPressed: (){},
              icon: Icon(Icons.notifications_none_outlined)
          ),
          SizedBox(width: 10,)
        ],
        leading: IconButton(
            onPressed: (){
              Navigator.of(context).pop();
            },
            icon: Icon(Icons.close),
        ),
      ),

      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.only(top: 40,left: 20,right: 20),
          child: Column(

            children: [

              Center(
                child: Stack(
                  alignment: Alignment.topRight,
                  children: [
                    Container(
                      height: 140,width: 140,
                      child: ClipRRect(
                        child: Image.asset(
                          'assets/user.png',
                          scale: 4.4,
                        ),
                        // Image.network('https://img.freepik.com/premium-vector/man-avatar-profile-picture-vector-illustration_268834-538.jpg'),
                      ),
                    ),
                    Positioned(
                      bottom: 0,
                      left: 55,
                      child: InkWell(onTap: (){},
                        child: Container(
                          height: 35,width: 35,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(50),
                            color: primaryDarkColor
                          ),
                          child: ClipOval(
                              child: Icon(Icons.edit,size: 25,color: accentColor,)
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 8,),
              Text('Name',style: TextStyle(fontWeight: FontWeight.bold),),
              Text('Name56566@gmail.com'),

              SizedBox(height: 20,),

              ListTile(
                onTap: () {},
                contentPadding: EdgeInsets.all(-10),
                title: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Icon(Icons.policy_outlined,size: 22,),
                    SizedBox(width: 30,),
                    Text('Privacy Policy',
                    ),
                  ],
                ),
              ),
              Divider(height: 0,),

              ListTile(
                onTap: () {},
                contentPadding: EdgeInsets.all(-10),
                title: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Icon(Icons.inventory_2_outlined,size: 22,),
                    SizedBox(width: 30,),
                    Text('Term and Conditions',
                    ),
                  ],
                ),
              ),
              Divider(height: 0,),

              ListTile(
                onTap: () {},
                contentPadding: EdgeInsets.all(-10),
                title: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Icon(Icons.delete_outline_outlined,size: 22,),
                    SizedBox(width: 30,),
                    Text('Delete',
                    ),
                  ],
                ),
              ),
              Divider(height: 0,),
              ListTile(
                onTap: () {},
                contentPadding: EdgeInsets.all(-10),
                title: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Icon(Icons.logout,size: 22,),
                    SizedBox(width: 30,),
                    Text('Logout',
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
