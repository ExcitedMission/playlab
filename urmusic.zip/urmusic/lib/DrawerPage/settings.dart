import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:urmusic/Color.dart';
import 'package:urmusic/Settings/audioQuality.dart';
import 'package:urmusic/Settings/driveMode.dart';
import 'package:urmusic/Settings/language.dart';
import 'package:urmusic/Settings/nowPlaying.dart';
import 'package:urmusic/Settings/privacy.dart';
import 'package:urmusic/Settings/termAndCondition.dart';
import 'package:urmusic/model_theme.dart';
class settings extends StatefulWidget {
  const settings({super.key});

  @override
  State<settings> createState() => _settingsState();
}

class _settingsState extends State<settings> {
  bool pushNotificationsEnabled = true;


  int selectedButton = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Settings',style: TextStyle(fontWeight: FontWeight.bold,),),
        centerTitle: true,
      ),

      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [

              ListTile(
                leading: Icon(Icons.brightness_6_outlined,color: primaryColor,),
                //contentPadding: EdgeInsets.all(8),
                title: Text('App Theme',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),

                subtitle: Text('Dark or Light Mode'),
              ),


              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    buildButton(0, 'Classic'),
                    buildButton(1, 'Dark '),
                    buildButton(2, 'Dark Blue'),
                    buildButton(3, 'Dark Gray'),
                  ],
                ),
              ),


              Divider(height: 0,),

              ListTile(
                onTap: (){},
                leading: Icon(Icons.clean_hands_outlined,color: greenColor,),
                title: Text('Cache',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15)),
                subtitle: Text('Clear cache data'),

                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                  Text('0 Bytes ',style: TextStyle(fontSize: 17)),
                  Icon(Icons.clean_hands_outlined,),
                ],),
              ),

              Divider(height: 0,),

              ListTile(
                leading: Icon(Icons.notifications_none_outlined,color: blueColor1,),
                // contentPadding: EdgeInsets.all(8),
                title: Text('Enable Push Notification',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15)),
                subtitle: Text('On/off Notification'),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Switch(
                      activeColor: greenColor,
                      focusColor: accentColor,
                      value: pushNotificationsEnabled,
                      onChanged: (value) {
                        setState(() {
                          pushNotificationsEnabled = value;
                        });
                        // Handle the push notification enable/disable action
                        print('Push Notifications ${value ? 'Enabled' : 'Disabled'}');
                      },
                    ),
                  ],
                ),
              ),

              Divider(height: 0,),
              ListTile(
                onTap: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>nowPlaying()));
                },

                leading: Icon(Icons.class_outlined,color: greenColor,),
                title: Text('Now playing',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15)),
                subtitle: Text('Customize your now playing screen'),
              ),
              Divider(height: 0,),
              ListTile(
                onTap: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>language()));
                },

                leading: Icon(Icons.language,color: greenColor,),
                //contentPadding: EdgeInsets.all(8),
                title: Text('Change Language',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15)),
                subtitle: Text('Customize your app language'),
                //trailing: Icon(Icons.switch_camera_outlined),
              ),

              Divider(height: 0,),
              ListTile(
                onTap: (){},

                leading: Icon(Icons.arrow_circle_up,color: greenColor,),
                title: Text('Subscriptions',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15)),
                subtitle: Text('Unlimited UR-MUSIC access'),
              ),

              Divider(height: 0,),
              ListTile(
                onTap: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>audioQuality()));
                },
                leading: Icon(Icons.music_note_outlined,color: yellowColor,),
                title: Text('Audio Quality',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15)),
                subtitle: Text('Customize audio quality'),
              ),

              Divider(height: 0,),
              ListTile(
                onTap: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>driveMode()));
                },
                leading: Icon(Icons.drive_eta_outlined,color: orangeColor,),
                title: Text('Drive mode',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15)),
                subtitle: Text('Customize your drive mode player screen'),
              ),

              Divider(height: 0,),
              ListTile(
                onTap: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>Privacy()));
                },
                leading: Icon(Icons.policy_outlined,color: primaryColor,),
                title: Text('Privacy Policy',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15)),
                subtitle: Text('This app privacy policy'),
              ),

              Divider(height: 0,),
              ListTile(
                onTap: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>termAndCondition()));
                },
                leading: Icon(Icons.assignment_outlined,color: purpleColor,),
                title: Text('Term and Conditions',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15)),
                subtitle: Text('This app Term and Conditions'),
              ),

              Divider(height: 0,),
              ListTile(
                onTap: (){},
                leading: Icon(Icons.error_outline_outlined,color: blueColor1,),
                title: Text('About Us',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15)),
                subtitle: Text('Social links, policy'),
              ),

            ],
          ),
        ),
      ),
    );
  }
  Widget buildButton(int index, String text) {
    return OutlinedButton(
      onPressed: () {
        setState(() {
          selectedButton = index;
          context.read<ModelTheme>().isDark = index == 1;
        });
      },
      style: OutlinedButton.styleFrom(
        minimumSize: Size(100, 28),
        elevation: 0,
        backgroundColor: selectedButton == index ? primaryColor : context.watch<ModelTheme>().isDark ? Colors.black : Colors.white,
      ),
      child: Text(text,style:
      TextStyle(color: selectedButton == index ? context.watch<ModelTheme>().isDark ? Colors.black : Colors.white : context.watch<ModelTheme>().isDark ? Colors.white : Colors.black,),),
    );
  }
}
