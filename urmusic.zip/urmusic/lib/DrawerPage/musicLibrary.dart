import 'package:flutter/material.dart';
class musicLibrary extends StatefulWidget {
  const musicLibrary({super.key});

  @override
  State<musicLibrary> createState() => _musicLibraryState();
}

class _musicLibraryState extends State<musicLibrary> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Music Library',
            style: const TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            )),
        centerTitle: true,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,

            children: [
              Container(
                //color: Colors.green,
                height: 700,
                // Adjust the height as needed
                child: ListView.builder(
                  scrollDirection: Axis.vertical,

                  itemCount: 1,
                  itemBuilder: (context, index) {
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          height: 195,width: 150,//color: Colors.grey,
                          margin: EdgeInsets.all(8),
                          child: Container(
                            child: Column(
                              children: [
                                Image.asset(
                                  'assets/singer.png',
                                  scale: 1.8,
                                  fit: BoxFit.cover,
                                ),

                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    SizedBox(width: 0,),
                                    Text('My Playlist'),
                                    IconButton(
                                        onPressed: (){},
                                        icon: Icon(Icons.more_vert_outlined)
                                    ),
                                  ],
                                )
                              ],
                            ),
                          ),
                        ),
                      ],
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
