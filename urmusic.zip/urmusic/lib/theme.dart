import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:urmusic/model_theme.dart';

class ThemeScreen extends StatefulWidget {
  const ThemeScreen({super.key});

  @override
  State<ThemeScreen> createState() => _ThemeScreenState();
}

class _ThemeScreenState extends State<ThemeScreen> {
  @override
  Widget build(BuildContext context) {
    Color backgroundColor = context.watch<ModelTheme>().isDark ? Colors.black : Colors.white;
    Color TColor = context.watch<ModelTheme>().isDark ? Colors.white : Colors.black;

    return SafeArea(child: Scaffold(

      appBar: AppBar(
        backgroundColor: backgroundColor,
        title: Text("Theme"/*language.rideHistory*/, style: TextStyle(fontWeight: FontWeight.bold,color: TColor)),
      ),
//      backgroundColor: backgroundColor,

      body: Column(
        children: [
          IconButton(
            icon: Icon(
              context.watch<ModelTheme>().isDark
                  ? Icons.nightlight_round
                  : Icons.wb_sunny,
            ),
            onPressed: () {
              context.read<ModelTheme>().toggleTheme();
            },
          )
        ],
      ),

    )
    );
  }
}
