import 'package:flutter/material.dart';
import 'package:urmusic/Color.dart';
import 'package:urmusic/NavigatorPage/homePage.dart';
import 'package:urmusic/navigation.dart';
import 'package:urmusic/registerPage.dart';
class loginPage extends StatefulWidget {
  const loginPage({super.key});

  @override
  State<loginPage> createState() => _loginPageState();
}

class _loginPageState extends State<loginPage> {
  GlobalKey<FormState> formkey=GlobalKey<FormState>();


  bool _obscureText = true;

  late String _password;
// Toggles the password show status
  void _toggle() {
    setState(() {
      _obscureText = !_obscureText;
    });
  }

  bool rememberMe = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(10.0),
          child: SingleChildScrollView(
            child: Form(key: formkey,
              child: Column(
                children: [

                  Image.asset('assets/image.png'),
                  SizedBox(height: 5,),

                  TextFormField(
                    decoration: InputDecoration(
                      hintText: 'Email ID',
                      labelText: 'Enter Email',
                      prefixIcon: Icon(Icons.alternate_email),
                    ),
                    validator: (val){
                      if(val!.isEmpty)
                      {
                        return 'Please a Enter';
                      }
                      if(!RegExp("^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+.[a-z]").hasMatch(val)){
                        return 'Please a valid Email';
                      }
                      return null;
                    },
                  ),
                  TextFormField(
                    //obscureText: true,
                    decoration: InputDecoration(
                      hintText: 'Password',
                      //border: InputBorder.none,
                      labelText: "Password",
                      //labelStyle: TextStyle(color: Colors.blueAccent)
                      prefixIcon: Icon(Icons.lock_outline),
                      // suffixIcon: Icon(Icons.remove_red_eye_outlined),
                      suffixIconColor: MaterialStateColor.resolveWith((states) =>
                      states.contains(MaterialState.focused)
                          ? Colors.grey
                          : Colors.black),

                      suffixIcon: IconButton(
                        icon: Icon(
                          _obscureText ? Icons.visibility_off_outlined : Icons.remove_red_eye_outlined,
                        ),
                        onPressed: () {
                          setState(() {
                            _obscureText = !_obscureText; // Toggle password visibility
                          });
                        },
                      ),
                    ),

                    validator: (val) => val!.length < 6 ? 'Password too short.' : null,
                    onSaved: (val) => _password = val!,
                    obscureText: _obscureText,

                  ),

                  SizedBox(height: 10,),
                  Row(
                    children: [
                      Checkbox(
                        shape: CircleBorder(),
                        focusColor: primaryColor,
                        //checkColor: primaryColor,
                        activeColor: primaryColor,

                        value: rememberMe,
                        onChanged: (value) {
                          setState(() {
                            rememberMe = value!;
                          });
                        },
                      ),
                      Text('Remember Me'),
                    ],
                  ),

                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: primaryColor,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10.0), // Set border radius here
                            ),
                          ),
                          onPressed: rememberMe ? (){
                              if(formkey.currentState!.validate()){
                                Navigator.push(context, MaterialPageRoute(builder: (context)=>navigation()));
                                print("ok");
                              }else{
                                print("Error");
                              }
                          } : null,

                          child: Text('Login',style: TextStyle(fontWeight: FontWeight.bold,color: accentColor),)
                      ),
                      OutlinedButton(
                          onPressed: (){},
                          style: ElevatedButton.styleFrom(
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10.0), // Set border radius here
                            ),
                          ),
                          child: Text('Skip')
                      ),
                    ],
                  ),

                  SizedBox(height: 10,),
                  InkWell(
                    onTap: (){},
                      child: Text('Forgot Your Password?',style: TextStyle(color: primaryColor,fontWeight: FontWeight.w500),)
                  ),

                  SizedBox(height: 20,),
                  OutlinedButton(
                    style: OutlinedButton.styleFrom(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10.0), // Set border radius here
                      ),
                    ),
                      onPressed: (){},
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Image.asset('assets/google.png',scale: 20,),
                          SizedBox(width: 20,),
                          Text('Login with Google',style: TextStyle(fontWeight: FontWeight.w500,color: primaryDarkColor),),
                        ],
                      )
                  ),

                  SizedBox(height: 10,),

                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text('New to Logistics?'),
                      InkWell(
                        onTap: (){
                          Navigator.push(context, MaterialPageRoute(builder: (context)=>registerPage()));
                        },
                          child: Text('Register',style: TextStyle(color: primaryColor,fontWeight: FontWeight.w500,fontSize: 17),)
                      )
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
