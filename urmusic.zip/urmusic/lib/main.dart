// import 'package:flutter/material.dart';
// import 'package:provider/provider.dart';
// import 'package:urmusic/loginPage.dart';
// import 'package:urmusic/model_theme.dart';
// import 'package:urmusic/theme.dart';
//
// void main() {
//   runApp(const MyApp());
// }
//
// class MyApp extends StatelessWidget {
//   const MyApp({super.key});
//
//   // This widget is the root of your application.
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       debugShowCheckedModeBanner: false,
//       title: 'Flutter Demo',
//
//       theme: ThemeData(
//           colorScheme: ColorScheme.fromSeed(seedColor: Colors.white),
//           useMaterial3: true,
//         ),
//       darkTheme: ThemeData(
//         colorScheme: ColorScheme.fromSeed(seedColor: Colors.black),
//         useMaterial3: true,
//       ),
//       themeMode: context.watch<ModelTheme>().isDark
//           ? ThemeMode.dark
//           : ThemeMode.light,
//
//       // theme: ThemeData(
//       //   colorScheme: ColorScheme.fromSeed(seedColor: Colors.black),
//       //   useMaterial3: true,
//       // ),
//       home: const ThemeScreen(),
//     );
//   }
// }
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:urmusic/loginPage.dart';
import 'package:urmusic/model_theme.dart';

void main() {
  runApp(
    ChangeNotifierProvider(
      create: (context) => ModelTheme(),
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'URMUSIC',
      theme: ThemeData.light(),
      darkTheme: ThemeData.dark(),
      themeMode: context.watch<ModelTheme>().isDark ? ThemeMode.dark : ThemeMode.light,
      home: const loginPage(),
    );
  }
}

