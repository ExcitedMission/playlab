import 'package:flutter/material.dart';
class Privacy extends StatefulWidget {
  const Privacy({super.key});

  @override
  State<Privacy> createState() => _PrivacyState();
}

class _PrivacyState extends State<Privacy> {
  int selectedValue = 1; // Initially selected value


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Privacy Policy ',style: TextStyle(fontWeight: FontWeight.w500),),

        leading: IconButton(
          onPressed: (){
            Navigator.pop(context);
          },
          icon: Icon(Icons.close),
        ),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(15.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text('Privacy Policy for URMUSIC',
                style: TextStyle(fontWeight: FontWeight.w500,fontSize: 26),),
              Text('Updated Dec 9,2023',style: TextStyle(fontSize: 18)),

            ],
          ),
        ),
      ),
    );
  }
}
