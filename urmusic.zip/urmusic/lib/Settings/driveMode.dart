import 'package:flutter/material.dart';
import 'package:urmusic/Color.dart';
class driveMode extends StatefulWidget {
  const driveMode({super.key});

  @override
  State<driveMode> createState() => _driveModeState();
}

class _driveModeState extends State<driveMode> {
  double _value =50;
  bool pushNotificationsEnabled = false;
  bool snow= false;
  bool screenOn = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Settings',style: TextStyle(fontWeight: FontWeight.w500,),),
        centerTitle: true,//Text('Settings',style: TextStyle(fontWeight: FontWeight.bold,),),,
      ),
      body: SafeArea(
        child: Column(
          children: [



            ListTile(
              leading: Icon(Icons.edit_road,color: primaryColor,),
              // contentPadding: EdgeInsets.all(8),
              title: Text('Adaptive color',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15)),
              subtitle: Text('The backgrounnd colors change according to the album art'),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Switch(
                    activeColor: greenColor,
                    focusColor: accentColor,
                    value: pushNotificationsEnabled,
                    onChanged: (value) {
                      setState(() {
                        pushNotificationsEnabled = value;
                      });
                      // Handle the push notification enable/disable action
                      print('Push Notifications ${value ? 'Enabled' : 'Disabled'}');
                    },
                  ),
                ],
              ),
            ),

            Divider(height: 0,),
            ListTile(
              leading: Icon(Icons.sunny_snowing,color: purpleColor,),
              // contentPadding: EdgeInsets.all(8),
              title: Text('Snow fall effect',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15)),
              subtitle: Text('Snow fall effect'),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Switch(
                    activeColor: greenColor,
                    focusColor: accentColor,
                    value: snow,
                    onChanged: (value) {
                      setState(() {
                        snow = value;
                      });
                      // Handle the push notification enable/disable action
                      print('Push Notifications ${value ? 'Enabled' : 'Disabled'}');
                    },
                  ),
                ],
              ),
            ),

            Divider(height: 0,),
            ListTile(
              leading: Icon(Icons.brightness_6_outlined,color: purpleColor,),
              // contentPadding: EdgeInsets.all(8),
              title: Text('Keep Screen on',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15)),
              subtitle: Text('Screen timeout'),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Switch(
                    activeColor: greenColor,
                    focusColor: accentColor,
                    value: screenOn,
                    onChanged: (value) {
                      setState(() {
                        screenOn = value;
                      });
                      // Handle the push notification enable/disable action
                      print('Push Notifications ${value ? 'Enabled' : 'Disabled'}');
                    },
                  ),
                ],
              ),
            ),
            Divider(height: 0,),


            ListTile(
              leading: Icon(Icons.snowing,color: blueColor,),
              // contentPadding: EdgeInsets.all(8),
              title: Text('Blur amount',style: TextStyle(fontWeight: FontWeight.bold,)),
              trailing: Text('${_value.round()}',style: TextStyle(fontSize: 15),),

              subtitle: SliderTheme(
                data: SliderTheme.of(context).copyWith(
                  activeTrackColor: primaryColor,
                  trackHeight: 1,
                  thumbShape: RoundSliderThumbShape(
                    enabledThumbRadius: 5.0, // Adjust the size of the thumb
                  ),
                  thumbColor: primaryColor,
                ),
                child: Slider(
                  value: _value,
                  min: 0,
                  max: 100,
                  //label: '$_value',
                  onChanged: (value) {
                    setState(() {
                      _value = value;
                    },);
                  },
                ),
              ),
            ),
            Text('Blur applied for themes, lower is faster')

          ],
        ),
      ),
    );
  }
}
