import 'package:flutter/material.dart';
class termAndCondition extends StatefulWidget {
  const termAndCondition({super.key});

  @override
  State<termAndCondition> createState() => _termAndConditionState();
}

class _termAndConditionState extends State<termAndCondition> {
  int selectedValue = 1; // Initially selected value


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Term and Conditions',style: TextStyle(fontWeight: FontWeight.w500),),

        leading: IconButton(
          onPressed: (){
            Navigator.pop(context);
          },
          icon: Icon(Icons.close),
        ),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(10.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text('Term & Conditions for URMUSIC',style: TextStyle(fontWeight: FontWeight.w500,fontSize: 26),),
              Text('Updated Dec 9,2023',style: TextStyle(fontSize: 18)),

            ],
          ),
        ),
      ),
    );
  }
}
