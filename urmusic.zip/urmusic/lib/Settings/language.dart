import 'package:flutter/material.dart';
import 'package:urmusic/Color.dart';
class language extends StatefulWidget {
  const language({super.key});

  @override
  State<language> createState() => _languageState();
}

class _languageState extends State<language> {
  int selectedValue = 1; // Initially selected value


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Language'),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              Row(
                children: [
                  Radio(
                    value: 1,
                    activeColor: primaryColor,
                    groupValue: selectedValue,
                    onChanged: (value) {
                      setState(() {
                        selectedValue = value as int;
                      });
                    },
                  ),Text('English'),
                ],
              ),

              Row(
                children: [
                  Radio(
                    activeColor: primaryColor,
                    value: 2,
                    groupValue: selectedValue,
                    onChanged: (value) {
                      setState(() {
                        selectedValue = value as int;
                      });
                    },
                  ),Text('Amharic'),
                ],
              ),



            ],
          ),
        ),
      ),
    );
  }
}
