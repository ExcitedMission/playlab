import 'package:flutter/material.dart';
import 'package:urmusic/Color.dart';
class audioQuality extends StatefulWidget {
  const audioQuality({super.key});

  @override
  State<audioQuality> createState() => _audioQualityState();
}

class _audioQualityState extends State<audioQuality> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
        title: Text('Settings',style: TextStyle(fontWeight: FontWeight.bold,),),
    centerTitle: true,
    ),

    body: SafeArea(
      child: SingleChildScrollView(
        child: Column(
            children: [


              ListTile(
                onTap: (){},
                leading: Icon(Icons.music_note_outlined,color: primaryColor,),
                title: Text('Audio Quality',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15)),
                subtitle: Text('Customize audio quality'),
              ),
              Divider(height: 0,),
              ListTile(
                onTap: (){},
                leading: Icon(Icons.download,color: purpleColor,),
                title: Text('Download Audio Quality',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15)),
                subtitle: Text('Customize download audio quality'),
              ),
              Divider(height: 0,),
            ],
          )
        )
      )
    );
  }
}
