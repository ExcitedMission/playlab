import 'package:flutter/material.dart';
import 'package:urmusic/Color.dart';
class nowPlaying extends StatefulWidget {
  const nowPlaying({super.key});

  @override
  State<nowPlaying> createState() => _nowPlayingState();
}

class _nowPlayingState extends State<nowPlaying> {
  double _value =50;
  bool pushNotificationsEnabled = false;
  bool snow= false;
  bool screenOn = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Settings',style: TextStyle(fontWeight: FontWeight.w500,),),
        centerTitle: true,//Text('Settings',style: TextStyle(fontWeight: FontWeight.bold,),),,
      ),
      body: SafeArea(
        child: Column(
          children: [

            ListTile(
              onTap: (){},
              leading: Icon(Icons.play_arrow,color: primaryColor,),
              // contentPadding: EdgeInsets.all(8),
              title: Text('Now playing theme',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15)),
              subtitle: Text('Customize your now playing screen theme'),
            ),

            Divider(height: 0,),
            ListTile(
              leading: Icon(Icons.volume_up,color: purpleColor,),
              // contentPadding: EdgeInsets.all(8),
              title: Text('Volume controls',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15)),
              subtitle: Text('If enough space is available, show volume controls in athe now playing screen'),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Switch(
                    activeColor: greenColor,
                    focusColor: accentColor,
                    value: snow,
                    onChanged: (value) {
                      setState(() {
                        snow = value;
                      });
                      // Handle the push notification enable/disable action
                      print('Push Notifications ${value ? 'Enabled' : 'Disabled'}');
                    },
                  ),
                ],
              ),
            ),

            Divider(height: 0,),
            ListTile(
              leading: Icon(Icons.bubble_chart_outlined,color: blueColor,),
              // contentPadding: EdgeInsets.all(8),
              title: Text('Snow fall effect',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15)),
              subtitle: Text('Only support dark mode'),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Switch(
                    activeColor: greenColor,
                    focusColor: accentColor,
                    value: screenOn,
                    onChanged: (value) {
                      setState(() {
                        screenOn = value;
                      });
                      // Handle the push notification enable/disable action
                      print('Push Notifications ${value ? 'Enabled' : 'Disabled'}');
                    },
                  ),
                ],
              ),
            ),
            Divider(height: 0,),


            ListTile(
              leading: Icon(Icons.snowing,color: blueColor1,),
              // contentPadding: EdgeInsets.all(8),
              title: Text('Blur amount',style: TextStyle(fontWeight: FontWeight.bold,)),
              trailing: Text('${_value.round()}',style: TextStyle(fontSize: 15),),

              subtitle: SliderTheme(
                data: SliderTheme.of(context).copyWith(
                  activeTrackColor: primaryColor,
                  trackHeight: 1,
                  thumbShape: RoundSliderThumbShape(
                    enabledThumbRadius: 5.0, // Adjust the size of the thumb
                  ),
                  thumbColor: primaryColor,
                ),
                child: Slider(
                  value: _value,
                  min: 0,
                  max: 100,
                  //label: '$_value',
                  onChanged: (value) {
                    setState(() {
                      _value = value;
                    },);
                  },
                ),
              ),
            ),
            Text('Blur applied for themes, lower is faster'),

            Divider(height: 0,),
            ListTile(
              onTap: (){},
              leading: Icon(Icons.text_fields,color: primaryColor,),
              title: Text('Lyrics font size',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15)),
              subtitle: Text('Select Font Size'),
            ),
          ],
        ),
      ),
    );
  }
}
